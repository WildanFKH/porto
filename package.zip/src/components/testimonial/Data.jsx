import Image1 from "../../assets/Testimonial1.JPG";
import Image2 from "../../assets/Testimonial2.JPG";
import Image3 from "../../assets/Testimonial3.JPG";
import Image4 from "../../assets/Testimonial4.JPG";
import Image5 from "../../assets/Testimonial5.JPG";

export const Data = [
    {
        id: 1,
        image: Image1,
        title: "Indah Maulida",
        description: "A really good job, all aspects of the project were followed step by step and with good results.",
    },
    {
        id: 2,
        image: Image2,
        title: "Ahmad Numan Latief",
        description: "A really good job, all aspects of the project were followed step by step and with good results.",
    },
    {
        id: 3,
        image: Image3,
        title: "Syahrul Fauzi",
        description: "A really good job, all aspects of the project were followed step by step and with good results.",
    },
    {
        id: 4,
        image: Image4,
        title: "Ian Ferdiansyah",
        description: "A really good job, all aspects of the project were followed step by step and with good results.",
    },
    {
        id: 5,
        image: Image5,
        title: "Nur Kholis Septiyadi",
        description: "A really good job, all aspects of the project were followed step by step and with good results.",
    },
];